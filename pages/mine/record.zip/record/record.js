// pages/mine/record/record.js
var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
  dat:'',
  aa:false,
  GroupName:'',
   LastRank:'',
  ThisRank:'',
  TimeInGroup:''
 
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that=this
    wx.request({
      url: app.globalData.url + '/getMyRunListUP', 
      data: {
        Id: app.globalData.Id
      },
      header: {
        'content-type': 'application/json'
      },
      success: function (res) {
        that.setData({
          dat:res
        })
        console.log(that.data.dat,'13145555')
      }
    })
  },
  recordTap: function () {
    wx.navigateTo({
      url: '../analysis1/analysis1',
    })
  },
  warp:function(e){
    var Id = e.currentTarget.dataset.index
    var that = this
    console.log(Id)
    wx.request({
      url: app.globalData.url + '/runDetail',
      data: {
        Id: Id
      },
      
      header: {
        'content-type': 'application/json'
      },
      success: function (res) {
        console.log(res)
        wx.navigateTo({
          url:
          '../../uploading/upSuccess/upSuccess?hour=' + res.data[0].hour
          + '&minute=' + res.data[0].minute
          + '&second=' + res.data[0].second
          + '&point=' + res.data[0].Point
          + '&long=' + res.data[0].Distance
          + '&flag=' + that.data.aa
          + '&url=' + res.data[0].ImgUrl
          + '&GroupName=' + that.data.GroupName
          + '&NickName=' + res.data[0].NickName
          + '&TimeAll=' + res.data[0].TimeAll
          + '&TotalPoints=' + res.data[0].TotalPoints
          + '&TotalRun=' + res.data[0].TotalRun
          + '&LastRank=' + that.data.LastRank
          + '&ThisRank=' + that.data.ThisRank
          + '&TimeInGroup=' + that.data.TimeInGroup
          + '&AdvQRUrl=' + res.data[1].AdvQRUrl
          + '&AdvTitle=' + res.data[1].AdvTitle
        })
        
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})